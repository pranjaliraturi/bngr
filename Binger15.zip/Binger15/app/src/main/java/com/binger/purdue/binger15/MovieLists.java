package com.binger.purdue.binger15;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MovieLists extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_lists);
    }
}
import java.awt.*;
        import java.awt.event.*;
        import javax.swing.*;


// end public class MovieLIst

