package com.binger.purdue.binger15;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.awt.*;

import javax.swing.*;

import java.lang.reflect.Array;
import java.util.*;
import java.util.List;

public class Schedule extends AppCompatActivity {
    private Button button5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_Schedule);

        button5 = (Button) findViewById(R.id.button);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogIn();
            }
        });

        });


public class Schedule extends AppCompatActivity {
    boolean checker = false;

    public int hournum(){
        return hourArray.size();
    }
    List<String> startEndTimes = new ArrayList<>();
    List<Integer> hourArray = new ArrayList<>();

    //CONSTRUCTOR
    public Schedule() {

        //the form


        //ADD SCROLLPANE

        //THE TABLE

        //THE MODEL OF OUR TABLE
        //DefaultTableModel model = new DefaultTableModel() {


        //OBTAIN SELECTED ROW
        JButton btn = new JButton("Get Selected");
        btn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                // TODO Auto-generated method stub


                //GET SELECTED
                for (int c = 1; c < 8; c++) {
                    for (int r = 0; r < 24; r++) {
                        Boolean checked = Boolean.valueOf(table.getValueAt(r, c).toString());

                        //DISPLAY
                        if (checked.equals(false)) {
                            int counter = 0;
                            int startCol = c;
                            int startRow = r;

                            String start = " " + r;
                            if (startCol == 1)
                                start = "Monday," + r;
                            if (startCol == 2)
                                start = "Tuesday," + r;
                            if (startCol == 3)
                                start = "Wednesday," + r;
                            if (startCol == 4)
                                start = "Thursday," + r;
                            if (startCol == 5)
                                start = "Friday," + r;
                            if (startCol == 6)
                                start = "Saturday," + r;
                            if (startCol == 7)
                                start = "Sunday," + r;
                            System.out.println("start" + start);
                            while (checked.equals(false)) {
                                counter++;
                                r++;
                                if (r == 24) {
                                    c++;
                                    r = 0;
                                }
                                if (r == 23 && c == 7)
                                    break;
                                checked = Boolean.valueOf(table.getValueAt(r, c).toString());
                            }//end while loop

                            int endCol = c;
                            int endRow = r;

                            String end = " " + endRow;
                            if (endCol == 1)
                                end = "Monday," + endRow;
                            if (endCol == 2)
                                end = "Tuesday," + endRow;
                            if (endCol == 3)
                                end = "Wednesday," + endRow;
                            if (endCol == 4)
                                end = "Thursday," + endRow;
                            if (endCol == 5)
                                end = "Friday," + endRow;
                            if (endCol == 6)
                                end = "Saturday," + endRow;
                            if (endCol == 7)
                                end = "Sunday," + endRow;

                            System.out.println("end" + end);

                            hourArray.add(counter);
                            System.out.println("hourArray:" + hourArray);
                            startEndTimes.add(start);
                            startEndTimes.add(end);
                            System.out.println("startEndTimes:" + startEndTimes);
                        }//end while loop
                    }//end row for loop
                }//end column for loop
            }//end button actionPerformed
        });
        //ADD BUTTON TO FORM

    }
}

